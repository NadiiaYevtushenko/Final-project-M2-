export const categories = [
  { value: '', label: 'Виберіть категорію' },
  { value: '3d-printers-fdm', label: '3D Принтери FDM' },
  { value: '3d-printers-sla', label: '3D Принтери SLA' },
  { value: '3d-printers-sls', label: '3D Принтери SLS' },
  { value: '3d-scanners', label: '3D Сканери' },
  { value: 'fdm-materials', label: 'Матеріали FDM' },
];
