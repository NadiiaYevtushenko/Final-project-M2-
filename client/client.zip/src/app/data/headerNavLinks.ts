const headerNavLinks = [
  { href: '/', title: 'Головна' },
  { href: '/shop', title: 'Магазин' },
  { href: '/services', title: 'Послуги' },
  { href: '/contact', title: 'Контакти' },
];

export default headerNavLinks;
